var searchData=
[
  ['size',['Size',['../class_translucent_image_source.html#a05a4ccc7e1990647889c634cc30b973e',1,'TranslucentImageSource']]],
  ['strength',['Strength',['../class_translucent_image_source.html#affdb4c09daa320bfb7370fa943b7f152',1,'TranslucentImageSource']]]
];
