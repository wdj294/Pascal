var searchData=
[
  ['downsample',['Downsample',['../class_translucent_image_source.html#a7b033d877c05edd8aae67a986186082d',1,'TranslucentImageSource']]]
];
