var indexSectionsWithContent =
{
  0: "bcdimprstv",
  1: "t",
  2: "prs",
  3: "mpsv",
  4: "bcdims"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Properties"
};

