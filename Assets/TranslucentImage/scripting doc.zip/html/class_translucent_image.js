var class_translucent_image =
[
    [ "GetModifiedMaterial", "class_translucent_image.html#ac24b33ba8447c6d09ca54a2bb8ff84a8", null ],
    [ "LateUpdate", "class_translucent_image.html#a636512474fae97fcf69e5e9a518e442e", null ],
    [ "ReCaculateUV", "class_translucent_image.html#ae5b90fed810249a4bc06a38462be45b6", null ],
    [ "RectTransformToRect", "class_translucent_image.html#a50639dd88e3b0206a0d4914063c9c208", null ],
    [ "Start", "class_translucent_image.html#aa1126605c8c33d94fed581e8b70c3ff1", null ],
    [ "source", "class_translucent_image.html#a584fd9b9bee8c67331093a79f80fbf9f", null ],
    [ "vibrancy", "class_translucent_image.html#ac789a086fdbde3393ac1b0061956fa56", null ]
];