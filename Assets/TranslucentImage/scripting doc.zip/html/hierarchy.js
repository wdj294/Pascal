var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "TranslucentImageSource", "class_translucent_image_source.html", null ]
    ] ],
    [ "RawImage", null, [
      [ "TranslucentImage", "class_translucent_image.html", null ]
    ] ]
];